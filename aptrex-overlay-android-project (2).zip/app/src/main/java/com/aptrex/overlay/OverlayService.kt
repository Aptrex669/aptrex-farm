package com.aptrex.overlay

import android.annotation.SuppressLint
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.LayoutInflater
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.TextView
import kotlin.math.abs

class OverlayService : Service() {

    private lateinit var windowManager: WindowManager
    private lateinit var overlayView: View
    private lateinit var bubbleView: View
    private lateinit var menuContainer: View
    private lateinit var mainPanel: View
    private lateinit var settingsPanel: View
    private lateinit var params: WindowManager.LayoutParams

    private val holdHandler = Handler(Looper.getMainLooper())
    private var hideTriggered = false
    private var savePreferences = false
    private var autoSizeVertically = false

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("ClickableViewAccessibility", "InflateParams")
    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        overlayView = LayoutInflater.from(this).inflate(R.layout.overlay_menu, null)

        val layoutType = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        } else {
            @Suppress("DEPRECATION")
            WindowManager.LayoutParams.TYPE_PHONE
        }

        params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            layoutType,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = 60
            y = 180
        }

        windowManager.addView(overlayView, params)

        bubbleView = overlayView.findViewById(R.id.floating_bubble)
        menuContainer = overlayView.findViewById(R.id.expanded_menu)
        mainPanel = overlayView.findViewById(R.id.main_features_panel)
        settingsPanel = overlayView.findViewById(R.id.settings_panel)

        val prefs = getSharedPreferences("aptrex_overlay_prefs", Context.MODE_PRIVATE)
        savePreferences = prefs.getBoolean("save_prefs", false)
        autoSizeVertically = prefs.getBoolean("auto_size_vert", false)

        // Wire 4 ON/OFF feature toggles
        wireTogglePair(R.id.check_1, R.id.btn_toggle_1, "feat_1", prefs)
        wireTogglePair(R.id.check_2, R.id.btn_toggle_2, "feat_2", prefs)
        wireTogglePair(R.id.check_3, R.id.btn_toggle_3, "feat_3", prefs)
        wireTogglePair(R.id.check_4, R.id.btn_toggle_4, "feat_4", prefs)

        // 5th Row (FARM SPEED CONTROL): opens Settings panel instead of ON/OFF
        overlayView.findViewById<View>(R.id.row_farm_speed_settings).setOnClickListener {
            mainPanel.visibility = View.GONE
            settingsPanel.visibility = View.VISIBLE
        }

        // Settings Option 1: Save feature preferences
        val saveCheck = overlayView.findViewById<CheckBox>(R.id.check_save_prefs)
        val saveBtn = overlayView.findViewById<TextView>(R.id.btn_save_prefs)
        fun syncSavePrefs(enabled: Boolean) {
            savePreferences = enabled
            saveCheck.isChecked = enabled
            saveBtn.text = if (enabled) "ON" else "OFF"
            prefs.edit().putBoolean("save_prefs", enabled).apply()
        }
        syncSavePrefs(savePreferences)
        saveCheck.setOnCheckedChangeListener { _, checked -> syncSavePrefs(checked) }
        saveBtn.setOnClickListener { syncSavePrefs(!savePreferences) }

        // Settings Option 2: Auto size vertically
        val autoSizeCheck = overlayView.findViewById<CheckBox>(R.id.check_auto_size)
        val autoSizeBtn = overlayView.findViewById<TextView>(R.id.btn_auto_size)
        fun syncAutoSize(enabled: Boolean) {
            autoSizeVertically = enabled
            autoSizeCheck.isChecked = enabled
            autoSizeBtn.text = if (enabled) "ON" else "OFF"
            prefs.edit().putBoolean("auto_size_vert", enabled).apply()
            params.height = if (enabled) WindowManager.LayoutParams.WRAP_CONTENT else WindowManager.LayoutParams.WRAP_CONTENT
            windowManager.updateViewLayout(overlayView, params)
        }
        syncAutoSize(autoSizeVertically)
        autoSizeCheck.setOnCheckedChangeListener { _, checked -> syncAutoSize(checked) }
        autoSizeBtn.setOnClickListener { syncAutoSize(!autoSizeVertically) }

        // BACK button inside Settings
        overlayView.findViewById<Button>(R.id.btn_back_settings).setOnClickListener {
            settingsPanel.visibility = View.GONE
            mainPanel.visibility = View.VISIBLE
        }

        // CLOSE MENU collapses back to floating icon
        overlayView.findViewById<Button>(R.id.btn_close_menu).setOnClickListener {
            settingsPanel.visibility = View.GONE
            mainPanel.visibility = View.VISIBLE
            menuContainer.visibility = View.GONE
            bubbleView.visibility = View.VISIBLE
        }

        // Floating icon: tap opens menu, drag moves, hold 3s hides icon
        setupDragAndClick(bubbleView, allowHoldToHide = true) {
            bubbleView.visibility = View.GONE
            menuContainer.visibility = View.VISIBLE
        }

        val headerDrag = overlayView.findViewById<View>(R.id.menu_header)
        setupDragAndClick(headerDrag, allowHoldToHide = false, onClick = null)
    }

    private fun wireTogglePair(
        checkId: Int,
        buttonId: Int,
        prefKey: String,
        prefs: android.content.SharedPreferences
    ) {
        val checkBox = overlayView.findViewById<CheckBox>(checkId)
        val statusBtn = overlayView.findViewById<TextView>(buttonId)

        fun syncVisual(isOn: Boolean) {
            checkBox.isChecked = isOn
            statusBtn.text = if (isOn) "ON" else "OFF"
            statusBtn.setTextColor(if (isOn) 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
            statusBtn.setBackgroundColor(if (isOn) 0xFF00E5FF.toInt() else 0xFF0D131D.toInt())
            if (savePreferences) {
                prefs.edit().putBoolean(prefKey, isOn).apply()
            }
        }

        val initial = if (savePreferences) prefs.getBoolean(prefKey, false) else false
        syncVisual(initial)

        checkBox.setOnCheckedChangeListener { _, isChecked -> syncVisual(isChecked) }
        statusBtn.setOnClickListener { syncVisual(!checkBox.isChecked) }
    }

    @SuppressLint("ClickableViewAccessibility")
    private fun setupDragAndClick(
        target: View,
        allowHoldToHide: Boolean,
        onClick: (() -> Unit)?
    ) {
        var initialX = 0
        var initialY = 0
        var initialTouchX = 0f
        var initialTouchY = 0f

        val holdToHideRunnable = Runnable {
            hideTriggered = true
            bubbleView.visibility = View.GONE
            stopSelf()
        }

        target.setOnTouchListener { _, event ->
            when (event.action) {
                MotionEvent.ACTION_DOWN -> {
                    initialX = params.x
                    initialY = params.y
                    initialTouchX = event.rawX
                    initialTouchY = event.rawY
                    hideTriggered = false
                    if (allowHoldToHide) {
                        holdHandler.postDelayed(holdToHideRunnable, 3000L)
                    }
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = (event.rawX - initialTouchX).toInt()
                    val dy = (event.rawY - initialTouchY).toInt()
                    if (abs(dx) > 10 || abs(dy) > 10) {
                        holdHandler.removeCallbacks(holdToHideRunnable)
                    }
                    params.x = initialX + dx
                    params.y = initialY + dy
                    windowManager.updateViewLayout(overlayView, params)
                    true
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    holdHandler.removeCallbacks(holdToHideRunnable)
                    val movedX = abs(event.rawX - initialTouchX)
                    val movedY = abs(event.rawY - initialTouchY)
                    if (!hideTriggered && movedX < 10 && movedY < 10 && event.action == MotionEvent.ACTION_UP) {
                        onClick?.invoke()
                    }
                    true
                }
                else -> false
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        holdHandler.removeCallbacksAndMessages(null)
        if (::overlayView.isInitialized) {
            windowManager.removeView(overlayView)
        }
    }
}